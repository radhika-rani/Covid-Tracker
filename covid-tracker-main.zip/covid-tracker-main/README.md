# covid-tracker
covid tracker with map intergration
completed the leaflet api
backend integrated
run with npm start

